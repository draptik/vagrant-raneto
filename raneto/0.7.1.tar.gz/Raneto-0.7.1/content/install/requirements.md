/*
Title: Requirements
Sort: 1
*/

To run Raneto you need to have the following:

* [Node.js](http://nodejs.org) **v0.10+**

Here a [list of services](https://github.com/joyent/node/wiki/Node-Hosting) that provide Node hosting
if you are looking to publish your knowledgebase online.
