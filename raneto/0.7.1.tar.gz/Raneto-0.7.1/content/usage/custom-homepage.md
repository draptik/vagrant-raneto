/*
Title: Custom Homepage
Sort: 5
*/

Be default Raneto shows a Knowledgebase homepage which lists your articles (and categories) and has
a regular Knowledgebase design.

However if you want to override this page and have a custom homepage you can create an `index.md` file
in the `content` folder which will be treated like a regular page.
