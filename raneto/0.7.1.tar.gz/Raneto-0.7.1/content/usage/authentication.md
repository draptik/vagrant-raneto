/*
Title: Authentication
Sort: 1
*/

## Authentication

To enable basic Authentication in Raneto is very simple.

In `config.js`

Change `authentication` to `true`.

Change `credentials` to your desired username and password.

Restart the server, if running, and you're ready to roll, privately.